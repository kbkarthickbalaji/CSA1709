# CSA1709-AI-LAB-PY
This repository contains the problem that I have learnt and solved related to AI
